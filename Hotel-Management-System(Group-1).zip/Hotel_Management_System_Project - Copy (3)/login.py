import tkinter as tk
from tkinter import messagebox
import pymysql  # type: ignore
import subprocess
from tkinter import PhotoImage

# Function to clear the placeholder text when entry widget gains focus
def clear_placeholder(event, entry, placeholder):
    if entry.get() == placeholder:
        entry.delete(0, tk.END)
        entry.config(fg="black")

# Function to add a placeholder text to entry widget
def add_placeholder(entry, placeholder):
    entry.insert(0, placeholder)
    entry.config(fg="grey")
    entry.bind('<FocusIn>', lambda event, entry=entry, placeholder=placeholder: clear_placeholder(event, entry, placeholder))
    entry.bind('<FocusOut>', lambda event, entry=entry, placeholder=placeholder: restore_placeholder(event, entry, placeholder))

# Function to restore placeholder text when entry widget loses focus and is empty
def restore_placeholder(event, entry, placeholder):
    if not entry.get():
        entry.delete(0, tk.END)
        entry.insert(0, placeholder)
        entry.config(fg="grey")

# Function to authenticate user login credentials
def authenticate(username, password):
    try:
        with pymysql.connect(
            host="localhost",
            user="root",
            password="",
            database="Hotel_Management_System"
        ) as connection:
            cursor = connection.cursor()
            cursor.execute("SELECT * FROM login WHERE username=%s AND password=%s", (username, password))
            user = cursor.fetchone()
            if user:
                return True
            else:
                return False
    except pymysql.Error as e:
        messagebox.showerror("Error", f"Error connecting to database: {e}")
        return False

# Function to handle login process
def login():
    username = username_entry.get()
    password = password_entry.get()

    # Check if username and password are provided
    if username == "" or password == "":
        messagebox.showerror("Login Failed", "Don't forget to input the username and password!")
    elif authenticate(username, password):
        messagebox.showinfo("Login Successful", "Login Successfully!")
        root.destroy()
        subprocess.Popen(["python", "Main.py"])
    else:
        messagebox.showerror("Login Failed", "Invalid username or password")

# Function to create a new account
def create_account_window():
    account_window = tk.Toplevel(root)
    account_window.title("Create Account")
    account_window.geometry("1600x1000")

    image = tk.PhotoImage(file="forlogin.png")
    resized_image = image.zoom(1, 2)
    image_label = tk.Label(account_window, image=resized_image)
    image_label.image = resized_image  # Keep a reference to avoid garbage collection
    image_label.place(x=-500, y=5)

    top_panel = tk.Frame(account_window, bg="#222831", width=2000, height=80, borderwidth=0, highlightthickness=0)
    top_panel.pack(side="top", fill="x") 
    label = tk.Label(top_panel, text="HOTEL MANAGEMENT SYSTEM", font=("Verdana", 24, "bold"), bg="#222831", fg="#EEEEEE")
    label.place(relx=0.5, rely=0.5, anchor="center")
    create_account_label = tk.Label(account_window, text="Create an Account", font=("Narrow Arial", 35, "bold"))
    create_account_label.place(x=1000, y=100)

    username_label = tk.Label(account_window, text="Username", font=("Verdana", 10, "bold"))
    username_label.place(x=1000, y=230)

    new_username_entry = tk.Entry(account_window, width=30, highlightbackground="blue", highlightthickness=0.5, font=(12))
    new_username_entry.place(x=1000, y=260)

    password_label = tk.Label(account_window, text="Password", font=("Verdana", 10, "bold"))
    password_label.place(x=1000, y=320)

    new_password_entry = tk.Entry(account_window, show="*", width=30, highlightbackground="blue", highlightthickness=0.5, font=(12))
    new_password_entry.place(x=1000, y=350)

    show_password_var = tk.BooleanVar()
    show_password_checkbox = tk.Checkbutton(account_window, text="Show Password", variable=show_password_var,
                                            command=lambda: show_hide_password(new_password_entry, show_password_var))
    show_password_checkbox.place(x=1000, y=390)

    create_account_button = tk.Button(account_window, text="Create Account",
                                      command=lambda: create_account(new_username_entry.get(), new_password_entry.get(), account_window), font=("Verdana", 10, "bold"), width=30, bg="Green", fg="white")
    create_account_button.place(x=1030, y=440)
    
    cancel_button = tk.Button(account_window, text="Cancel", font=("Verdana", 10, "bold"), width=30, bg="red", fg="white",
                              command=account_window.destroy)
    cancel_button.place(x=1030, y=470)

# Function to add a new account to the database
def create_account(username, password, account_window):
    try:
        with pymysql.connect(
            host="localhost",
            user="root",
            password="",
            database="Hotel_Management_System"
        ) as connection:
            cursor = connection.cursor()
            cursor.execute("INSERT INTO login (username, password) VALUES (%s, %s)", (username, password))
            connection.commit()
            messagebox.showinfo("Account Created", "Your account has been created successfully!")
            account_window.destroy()
    except pymysql.Error as e:
        messagebox.showerror("Error", f"Error creating account: {e}")

# Function to handle forgot password functionality
def forgot_password_window():
    forgot_password = tk.Toplevel(root)
    forgot_password.title("Forgot Password")
    forgot_password.geometry("1600x1000")


    image = tk.PhotoImage(file="forlogin.png")
    resized_image = image.zoom(1, 2)
    image_label = tk.Label(forgot_password, image=resized_image)
    image_label.image = resized_image  # Keep a reference to avoid garbage collection
    image_label.place(x=-500, y=5)
    top_panel = tk.Frame(forgot_password, bg="#222831", width=2000, height=80, borderwidth=0, highlightthickness=0)
    top_panel.pack(side="top", fill="x") 
    label = tk.Label(top_panel, text="HOTEL MANAGEMENT SYSTEM", font=("Verdana", 24, "bold"), bg="#222831", fg="#EEEEEE")
    label.place(relx=0.5, rely=0.5, anchor="center")

    forgot_label = tk.Label(forgot_password, text="Forgot Password", font=("Narrow Arial", 35, "bold"))
    forgot_label.place(x=1000, y=100)

    username_label = tk.Label(forgot_password, text="Username", font=("Verdana", 10, "bold"))
    username_label.place(x=1000, y=230)

    username_entry_fp = tk.Entry(forgot_password, width=30, highlightbackground="blue", highlightthickness=0.5, font=(12))
    username_entry_fp.place(x=1000, y=260)

    new_password_label = tk.Label(forgot_password, text="New Password", font=("Verdana", 10, "bold"))
    new_password_label.place(x=1000, y=320)

    new_password_entry_fp = tk.Entry(forgot_password, show="*", width=30, highlightbackground="blue", highlightthickness=0.5, font=(12))
    new_password_entry_fp.place(x=1000, y=350)

    show_password_var = tk.BooleanVar()
    show_password_checkbox = tk.Checkbutton(forgot_password, text="Show Password", variable=show_password_var,
                                            command=lambda: show_hide_password(new_password_entry_fp, show_password_var))
    show_password_checkbox.place(x=1000, y=390)

    change_password_button = tk.Button(forgot_password, text="Change Password", font=("Verdana", 10, "bold"), width=30, bg="blue", fg="white",
                                       command=lambda: change_password(username_entry_fp.get(), new_password_entry_fp.get(), forgot_password))
    change_password_button.place(x=1030, y=440)
    
    cancel_button = tk.Button(forgot_password, text="Cancel", font=("Verdana", 10, "bold"), width=30, bg="red", fg="white",
                              command=forgot_password.destroy)
    cancel_button.place(x=1030, y=470)

# Function to show or hide password
def show_hide_password(entry_widget, show_password_var):
    if show_password_var.get():
        entry_widget.config(show="")
    else:
        entry_widget.config(show="*")

# Function to change password
def change_password(username, new_password, forgot_password_window):
    try:
        with pymysql.connect(
            host="localhost",
            user="root",
            password="",
            database="Hotel_Management_System"
        ) as connection:
            cursor = connection.cursor()
            cursor.execute("UPDATE login SET password=%s WHERE username=%s", (new_password, username))
            connection.commit()
            messagebox.showinfo("Password Changed", "Your password has been changed successfully!")
            forgot_password_window.destroy()
    except pymysql.Error as e:
        messagebox.showerror("Error", f"Error changing password: {e}")

# Create the root window
root = tk.Tk()
root.title("Login")
root.geometry("1600x1000")

# Set background image
image = PhotoImage(file="forlogin.png")
width, height = image.width(), image.height()
image = image.zoom(1, 2)
imagebg = tk.Label(root, image=image)
imagebg.place(x=-300, y=5)
imagebg.lower()

# Creating top panel for the application
top_panel = tk.Frame(root, bg="#222831", width=2000, height=80, borderwidth=0, highlightthickness=0)
top_panel.pack(side="top", fill="x") 
label = tk.Label(top_panel, text="HOTEL MANAGEMENT SYSTEM", font=("Verdana", 24, "bold"), bg="#222831", fg="#EEEEEE")
label.place(relx=0.5, rely=0.5, anchor="center")
# Login label
login_label = tk.Label(root, text="Login", font=("Narrow Arial", 45, "bold"))
login_label.place(x=1090, y=100)

username_label = tk.Label(root, text="USERNAME", font=("Verdana", 10, "bold"))
username_label.place(x=1000, y=230)

# Username entry
username_entry = tk.Entry(root, width=30, highlightbackground="blue", highlightthickness=0.5, font=(12))
username_entry.place(x=1000, y=260)

# Password entry
password_label = tk.Label(root, text="PASSWORD", font=("Verdana", 10, "bold"))
password_label.place(x=1000, y=320)
password_entry = tk.Entry(root, show="*", width=30, highlightbackground="blue", highlightthickness=0.5, font=(12))
password_entry.place(x=1000, y=350)

# Checkbox to show password
show_password_var = tk.BooleanVar()
show_password_checkbox = tk.Checkbutton(root, text="Show Password", variable=show_password_var, command=lambda: show_hide_password(password_entry, show_password_var))
show_password_checkbox.place(x=1000, y=390)

# Login button
login_button = tk.Button(root, text="Login", command=login, font=("Verdana", 10, "bold"), width=30, bg="blue", fg="white")
login_button.place(x=1030, y=470)

# Create account button
create_account_button = tk.Button(root, text="Create Account", command=create_account_window, font=("Verdana", 10, "bold"), width=30, bg="Green", fg="white")
create_account_button.place(x=1030, y=510)

# Forgot password button
forgot_password_button = tk.Button(root, text="Forgot Password", command=forgot_password_window, fg="red")
forgot_password_button.place(x=1234, y=390)

# Run the application
root.mainloop()
