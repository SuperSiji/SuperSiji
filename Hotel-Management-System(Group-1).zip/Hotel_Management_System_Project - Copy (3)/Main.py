import pymysql  # type: ignore
import tkinter as tk
from tkinter import ttk
from tkcalendar import Calendar  # type: ignore
import tkinter.messagebox as messagebox
import subprocess
from datetime import datetime
from tkinter import simpledialog


root = tk.Tk()
root.title("Main")
root.configure(bg="white")
root.geometry("1600x1000") 


connection = pymysql.connect(
    host="localhost",
    user="root",
    password="",
    database="Hotel_Management_System"
)


def fetch_room_count():
    connection = pymysql.connect(
        host="localhost",
        user="root",
        password="",
        database="Hotel_Management_System"
    )
    try:
        with connection.cursor() as cursor:
            sql = "SELECT COUNT(room_number) FROM available_rooms"
            cursor.execute(sql)
            count = cursor.fetchone()[0]
            return count
    except pymysql.Error as e:
        messagebox.showerror("Error", f"Error fetching data: {e}")
        return 0
    finally:
        connection.close()
def fetch_number_of_guests():
    connection = pymysql.connect(
        host="localhost",
        user="root",
        password="",
        database="Hotel_Management_System"
    )
    try:
        with connection.cursor() as cursor:
            sql = "SELECT SUM(No_Guest) FROM hotel_customer"
            cursor.execute(sql)
            count = cursor.fetchone()[0]
            return count
    except pymysql.Error as e:
        messagebox.showerror("Error", f"Error fetching data: {e}")
        return 0
    finally:
        connection.close()

def fetch_refresh_table():
    connection = pymysql.connect(
        host="localhost",
        user="root",
        password="",
        database="Hotel_Management_System"
    )
    try:
        with connection.cursor() as cursor:
                sql = """
                SELECT ID, Room_Name, Check_in_Date, Check_out_Date, Bill, Cash, `Change`, 
                       Name, Services, Timein, Timeout, No_Guest, Number_Days
                FROM hotel_customer
                """
                cursor.execute(sql)
                return
    except pymysql.Error as e:
            messagebox.showerror("Error", f"Error fetching data: {e}")

def fetch_total_income():
    connection = pymysql.connect(
        host="localhost",
        user="root",
        password="",
        database="Hotel_Management_System"
    )
    try:
        with connection.cursor() as cursor:
            sql = "SELECT SUM(bill) FROM checkout_table"
            cursor.execute(sql)
            total = cursor.fetchone()[0]
            return total if total else 0
    finally:
        connection.close()
        

def fetch_occupied_room_count():
    connection = pymysql.connect(
        host="localhost",
        user="root",
        password="",
        database="Hotel_Management_System"
    )
    try:
        with connection.cursor() as cursor:
            sql = "SELECT COUNT(room_name) FROM hotel_customer"
            cursor.execute(sql)
            count = cursor.fetchone()[0]
            return count
    except pymysql.Error as e:
        messagebox.showerror("Error", f"Error fetching data: {e}")
        return 0
    finally:
        connection.close()

def update_counts():
    available_count = fetch_room_count()
    occupied_count = fetch_occupied_room_count()
    total_income_value = fetch_total_income()
    number_of_guests = fetch_number_of_guests() 
    
    room_available.config(state='normal')
    room_available.delete(0, tk.END)
    room_available.insert(0, available_count)
    room_available.config(state='readonly')
    
    room_occupied.config(state='normal')
    room_occupied.delete(0, tk.END)
    room_occupied.insert(0, occupied_count)
    room_occupied.config(state='readonly')
    
    total_income.config(state='normal')
    total_income.delete(0, tk.END)
    total_income.insert(0, total_income_value)
    total_income.config(state='readonly', justify='center')
    
    number_guest.config(state='normal')  
    number_guest.delete(0, tk.END)
    number_guest.insert(0, int(number_of_guests))
    number_guest.config(state='readonly', justify='center') 
    
    fetch_refresh_table()
root.after(1000, update_counts)



top_panel = tk.Frame(root, bg="#222831", width=2000, height=80, borderwidth=0, highlightthickness=0)
top_panel.pack(side="top", fill="x") 
label = tk.Label(top_panel, text="HOTEL MANAGEMENT SYSTEM", font=("Verdana", 24, "bold"), bg="#222831", fg="#EEEEEE")
label.place(relx=0.5, rely=0.5, anchor="center")


hi_admin = tk.Label(top_panel, text="Hi, Admin.", font=("Roboto", 12, ""), bg="#222831", fg="#EEEEEE")
hi_admin.place(x = 1300, y= 26)

button_logout = tk.Button(top_panel, text="Logout", font=("Verdana", 10, ""), bg="Red", fg="White", border=2, command=lambda: subprocess.Popen(["python", "login.py"], root.destroy()))
button_logout.place(x=1450, y=26)


left_panel = tk.Frame(root, bg="#393E46", width=2000, height=900)
left_panel.pack(side="left", fill="y")


middle_panel = tk.Frame(root, borderwidth=0, highlightthickness=0, bg="White")
middle_panel.pack(side="left", fill="both", expand=True)


room_avail_label = tk.Label(middle_panel, text="Room Available", font=("Roboto", 12, "bold"), bg= "white", fg="blue")
room_avail_label.place(x = 100, y= 470)

room_available = tk.Entry(middle_panel, width=4,font=('Arial', 50, "bold"), bg='red', fg='#000000', state='readonly', justify='center')
room_available.place(x=80, y= 500)

room_occupied_label = tk.Label(middle_panel, text="Room Occupied", font=("Roboto", 12, "bold"), bg= "white", fg="blue" )
room_occupied_label.place(x = 415, y= 470)

room_occupied = tk.Entry(middle_panel, width=4, font=('Arial', 50, "bold"), bg='red', fg='#000000', state='readonly', justify='center')
room_occupied.place(x=400, y= 500) 

number_guest_label = tk.Label(middle_panel, text="Number of Guest", font=("Roboto", 12, "bold"), bg= "white", fg="blue")
number_guest_label.place(x = 710, y= 470)

number_guest = tk.Entry(middle_panel, width=4, font=('Arial', 50, "bold"), bg='red', fg='#000000', state='readonly')
number_guest.place(x=700, y= 500) 

total_income_label = tk.Label(middle_panel, text="Total Income", font=("Roboto", 12, "bold"), bg= "white", fg="Blue")
total_income_label.place(x = 1145, y= 470)

total_income = tk.Entry(middle_panel, width=10, font=('Arial', 50,"bold"), bg='yellow', fg='black', state='readonly')
total_income.place(x=1000, y= 500) 

about_panel = tk.Frame(middle_panel, bg="cyan", width=900, height=260)
about_panel.pack_propagate(False)
about_panel.place(x=250, y=70)


paragraph_text = """Welcome to our hotel management system! This system is designed to help you efficiently manage hotel reservations, customer check-ins and check-outs, billing, and much more. Our goal is to provide a seamless experience for both the hotel staff and the guests. We hope you enjoy using our system and find it beneficial in managing your hotel operations."""


paragraph_label = tk.Label(about_panel, text=paragraph_text,font=('Verdana', 17, ''),bg="cyan", wraplength=580, justify="left")
paragraph_label.pack(padx=10, pady=10)

paragraph_label = tk.Label(middle_panel, text="About",font=('Arial', 26, 'bold'),bg="white", fg='Red')
paragraph_label.place(x= 660, y=20)


room_count = fetch_room_count()
room_available.config(state='normal')
room_available.delete(0, tk.END)
room_available.insert(0, room_count)
room_available.config(state='readonly')


room_count = fetch_occupied_room_count()
room_occupied.config(state='normal')
room_occupied.delete(0, tk.END)
room_occupied.insert(0, room_count)
room_occupied.config(state='readonly')

def open_description_window(parent):
    description_window = tk.Toplevel(parent)
    description_window.title("Description") 
    description_window.configure(bg="white")
    description_window.geometry("800x100")

    label = tk.Label(description_window, text="A basic room equipped with a single bed, designed for one person. (Good for One Person)", font=("Roboto", 12, ""), bg= "white", fg="Black")
    label.place(x = 100, y= 40)

def open_description2_window(parent):
    description2_window = tk.Toplevel(parent)
    description2_window.title("Description")  
    description2_window.configure(bg="white")  
    description2_window.geometry("900x100")

    label = tk.Label(description2_window, text="A spacious room with one double bed, offering enhanced comfort and amenities. (Good for 2 or 3 person)", font=("Roboto", 12, ""), bg= "white", fg="Black")
    label.place(x = 100, y= 40)

def open_description3_window(parent):
    description3_window = tk.Toplevel(parent)
    description3_window.title("Description") 
    description3_window.configure(bg="white") 
    description3_window.geometry("1200x100")

    label = tk.Label(description3_window, text="A premium and expansive suite designed to accommodate families, often with separate bedrooms and living areas. (Good for 3 or more person)", font=("Roboto", 12, ""), bg= "white", fg="Black")
    label.place(x = 100, y= 40)

def open_dashboard(root):
    root.deiconify() 


def clear_placeholder(event, entry, placeholder): 
    if entry.get() == placeholder:
        entry.delete(0, tk.END)
        entry.config(fg="black")  


def add_placeholder(entry, placeholder):
    entry.insert(0, placeholder)
    entry.config(fg="grey")  
    entry.bind('<FocusIn>', lambda event, entry=entry, placeholder=placeholder: clear_placeholder(event, entry, placeholder))
    entry.bind('<FocusOut>', lambda event, entry=entry, placeholder=placeholder: restore_placeholder(event, entry, placeholder))


def restore_placeholder(event, entry, placeholder):
    if not entry.get():
        entry.delete(0, tk.END)
        entry.insert(0, placeholder)
        entry.config(fg="grey") 


def fetch_occupied_rooms_data(occupied_tree):
    try:
        with connection.cursor() as cursor:
            sql = "SELECT room_name FROM hotel_customer"
            cursor.execute(sql)
            rows = cursor.fetchall()
            for row in rows:
                occupied_tree.insert("", "end", values=row)
    except pymysql.Error as e:
        messagebox.showerror("Error", f"Error fetching occupied rooms data: {e}")


def fetch_rooms_data(tree, view_tree):
    try:
        with connection.cursor() as cursor:
            sql = "SELECT room_number FROM available_rooms"
            cursor.execute(sql)
            rows = cursor.fetchall()
            for row in rows:
                tree.insert("", "end", values=row)
                view_tree.insert("", "end", values=row)
    except pymysql.Error as e:
        messagebox.showerror("Error", f"Error fetching available rooms data: {e}")

def choose_room(tree, selected_room_entry):
    selected_item = tree.selection()
    if selected_item:
        room_number = tree.item(selected_item, "values")[0]
        selected_room_entry.configure(state='normal')
        selected_room_entry.delete(0, tk.END) 
        selected_room_entry.insert(0, room_number)  
        selected_room_entry.configure(state='readonly')


def open_choose_rooms_window(parent):

    choose_rooms_window = tk.Toplevel(parent)
    choose_rooms_window.title("Choose Rooms")
    choose_rooms_window.configure(bg="white")
    choose_rooms_window.overrideredirect(True)


    middle_width = parent.winfo_width()
    middle_height = parent.winfo_height()
    parent.update_idletasks()
    x = parent.winfo_rootx() + parent.winfo_width() // 2 - middle_width // 2
    y = parent.winfo_rooty() + parent.winfo_height() // 2 - middle_height // 2
    choose_rooms_window.geometry(f"{middle_width}x{middle_height}+{x}+{y}")


    single_room_panel = tk.Frame(choose_rooms_window, bg="cyan", width=500, height=500)
    single_room_panel.pack_propagate(False)
    single_room_panel.place(x=880, y=150)

    divider_panel = tk.Frame(choose_rooms_window, bg="#222831", width=10, height=1000)
    divider_panel.pack_propagate(False) 
    divider_panel.place(x=800, y=0)

    view_room_panel = tk.Frame(choose_rooms_window, bg="Yellow", width=700, height=250)
    view_room_panel.pack_propagate(False) 
    view_room_panel.place(x=55, y=90)

    occupied_panel = tk.Frame(choose_rooms_window, bg="Red", width=700, height=250)
    occupied_panel.pack_propagate(False)
    occupied_panel.place(x=55, y=460)


    tree_frame = tk.Frame(single_room_panel, bg="white")
    tree_frame.pack(fill="both", expand=True, padx=10, pady=10)

    style = ttk.Style()
    style.configure("Treeview.Heading", font=("Arial", 12, "bold"))


    tree = ttk.Treeview(tree_frame, columns=("room_number",), show="headings")
    tree.heading("room_number", text="CHOOSE ROOMS")
    tree.column("room_number", width=150, anchor=tk.CENTER)


    vsb = ttk.Scrollbar(tree_frame, orient="vertical", command=tree.yview)
    vsb.pack(side="right", fill="y")
    tree.configure(yscrollcommand=vsb.set)


    hsb = ttk.Scrollbar(tree_frame, orient="horizontal", command=tree.xview)
    hsb.pack(side="bottom", fill="x")
    tree.configure(xscrollcommand=hsb.set)


    tree.pack(fill="both", expand=True)


    view_tree = ttk.Treeview(view_room_panel, columns=("room_name",), show="headings")
    view_tree.heading("room_name", text="AVAILABLE ROOMS")
    view_tree.column("room_name", width=150, anchor=tk.CENTER)
    

    vsb_view = ttk.Scrollbar(view_room_panel, orient="vertical", command=view_tree.yview)
    vsb_view.pack(side="right", fill="y")
    view_tree.configure(yscrollcommand=vsb_view.set)


    hsb_view = ttk.Scrollbar(view_room_panel, orient="horizontal", command=view_tree.xview)
    hsb_view.pack(side="bottom", fill="x")
    view_tree.configure(xscrollcommand=hsb_view.set)


    view_tree.pack(fill="both", expand=True)


    occupied_tree = ttk.Treeview(occupied_panel, columns=("room",), show="headings")
    occupied_tree.heading("room", text="OCCUPIED ROOMS")
    occupied_tree.column("room", width=150, anchor=tk.CENTER)
    

    vsb_occupied = ttk.Scrollbar(occupied_panel, orient="vertical", command=occupied_tree.yview)
    vsb_occupied.pack(side="right", fill="y")
    occupied_tree.configure(yscrollcommand=vsb_occupied.set)


    hsb_occupied = ttk.Scrollbar(occupied_panel, orient="horizontal", command=occupied_tree.xview)
    hsb_occupied.pack(side="bottom", fill="x")
    occupied_tree.configure(xscrollcommand=hsb_occupied.set)


    occupied_tree.pack(fill="both", expand=True)


    fetch_rooms_data(tree, view_tree)
    fetch_occupied_rooms_data(occupied_tree)


    selected_room_entry = tk.Entry(single_room_panel, width=20, font=('Arial', 12), bg='white', fg='#000000', state='readonly', justify='center')
    selected_room_entry.pack(pady=10)


    choose_button = tk.Button(single_room_panel, text="Choose", width = 10, font=('Verdana', 12, ""),bg = "blue", fg='white', command=lambda: choose_room(tree, selected_room_entry))
    choose_button.pack(pady=10)

    add_checkin_label = tk.Label(single_room_panel, text="Room:", font=("Roboto", 12, "bold"), bg="cyan", fg="Black")
    add_checkin_label.place(x=94, y=364)



    next_button = tk.Button(single_room_panel, text="Next", width = 10, font=('Verdana', 12, ""),bg = "Green", fg='white', command=lambda: open_get_info_window(parent, selected_room_entry.get()))
    next_button.pack(pady=10)
    

def on_date_selected(cal, date_input):
    selected_date = cal.get_date()
    date_input.delete(0, tk.END)
    date_input.insert(0, selected_date)
    cal.place_forget()  

def show_calendar(cal):
    cal.place(x=740, y=100)

def open_get_info_window(parent, selected_room):
    def compute_days():
        try:
            checkin_date = datetime.strptime(date_input_checkin.get(), "%Y-%m-%d")
            checkout_date = datetime.strptime(date_input_checkout.get(), "%Y-%m-%d")
            num_days = (checkout_date - checkin_date).days
            compute_days_entry.delete(0, tk.END)
            compute_days_entry.insert(0, str(num_days))
        except ValueError:
            compute_days_entry.delete(0, tk.END)
            compute_days_entry.insert(0, "------")

    def on_date_selected(calendar, entry):
        selected_date = calendar.get_date()
        entry.delete(0, tk.END)
        entry.insert(0, selected_date)
        calendar.place_forget()  
        compute_days() 

    def show_calendar(calendar):
        calendar.place(x=740, y=100)

    def get_time(hour_var, minute_var, am_pm_var):
        hour = hour_var.get()
        minute = minute_var.get()
        am_pm = am_pm_var.get()
        return f"{hour}:{minute} {am_pm}"

    def update_hidden_time_entry(hidden_entry, hour_var, minute_var, am_pm_var):
        time_str = get_time(hour_var, minute_var, am_pm_var)
        hidden_entry.delete(0, tk.END)
        hidden_entry.insert(0, time_str)
        print(f"Selected Time: {time_str}") 

    def create_time_selector(parent, x, y, label_text, hidden_entry):
        time_label = tk.Label(parent, text=label_text, font=("Roboto", 10, "bold"), bg="cyan", fg="black")
        time_label.place(x=x, y=y)

        hour_var = tk.StringVar(value="12")
        hour_selector = ttk.Combobox(parent, textvariable=hour_var, values=[f"{i:02}" for i in range(1, 13)], width=5)
        hour_selector.place(x=x + 117, y=y)

        minute_var = tk.StringVar(value="00")
        minute_selector = ttk.Combobox(parent, textvariable=minute_var, values=[f"{i:02}" for i in range(60)], width=5)
        minute_selector.place(x=x + 167, y=y)

        am_pm_var = tk.StringVar(value="AM")
        am_pm_selector = ttk.Combobox(parent, textvariable=am_pm_var, values=["AM", "PM"], width=5)
        am_pm_selector.place(x=x + 217, y=y)


        hour_var.trace_add("write", lambda *args: update_hidden_time_entry(hidden_entry, hour_var, minute_var, am_pm_var))
        minute_var.trace_add("write", lambda *args: update_hidden_time_entry(hidden_entry, hour_var, minute_var, am_pm_var))
        am_pm_var.trace_add("write", lambda *args: update_hidden_time_entry(hidden_entry, hour_var, minute_var, am_pm_var))

        return hour_var, minute_var, am_pm_var

    def update_hidden_listbox_entry():
        selected_items = [listbox.get(i) for i in listbox.curselection()]
        selected_service_entry.delete(0, tk.END)
        selected_service_entry.insert(0, ', '.join(selected_items))
        print(f"Selected Items: {', '.join(selected_items)}")

    def update_hidden_number_of_guests_entry(*args):
        hidden_number_of_guests_entry.delete(0, tk.END)
        hidden_number_of_guests_entry.insert(0, guests_number_var.get())

    def proceed_to_billing():
        billing_data = {
            "room_number": room_name_entry.get(),
            "name": name_entry.get(),
            "phone_number": phone_number_entry.get(),
            "guests": guests_number_entry.get(),
            "checkin_date": date_input_checkin.get(),
            "checkout_date": date_input_checkout.get(),
            "num_days": compute_days_entry.get(),
            "timein": hidden_timein_entry.get(),
            "timeout": hidden_timeout_entry.get(),
            "services": selected_service_entry.get(),
        }
        open_billing_window(parent, billing_data, fetch_data_from_database)

    get_info_window = tk.Toplevel(parent)
    get_info_window.title("Get Info")
    get_info_window.overrideredirect(True)
    get_info_window.configure(bg="white")


    middle_width = parent.winfo_width()
    middle_height = parent.winfo_height()
    parent.update_idletasks()
    x = parent.winfo_rootx() + parent.winfo_width() // 2 - middle_width // 2
    y = parent.winfo_rooty() + parent.winfo_height() // 2 - middle_height // 2
    get_info_window.geometry(f"{middle_width}x{middle_height}+{x}+{y}")

    add_checkin_panel = tk.Frame(get_info_window, bg="cyan", width= 1000, height=550)
    add_checkin_panel.pack_propagate(False)
    add_checkin_panel.place(x=260, y=100)

    add_checkin_divider_panel = tk.Frame(add_checkin_panel, bg="black", width=5000, height=2)
    add_checkin_divider_panel.pack_propagate(False)
    add_checkin_divider_panel.place(x=0, y=70)

    add_checkin_label = tk.Label(get_info_window, text="Checkin Room", font=("Roboto", 24, "bold"), bg="cyan", fg="black")
    add_checkin_label.place(x=280, y=120)

    C_Date = tk.Label(add_checkin_panel, text="Checkin Date:", font=("Arial", 10, "bold"), bg="cyan", fg="black")
    C_Date.place(x=468, y=160)

    date_frame_checkin = tk.Frame(add_checkin_panel, bg="grey")
    date_frame_checkin.place(x=570, y=150)

    date_input_checkin = tk.Entry(date_frame_checkin, width=20, relief=tk.FLAT, borderwidth=10)
    date_input_checkin.pack(side=tk.LEFT)

    show_calendar_button_checkin = tk.Button(date_frame_checkin, text="📅", font=("Arial", 12), bg="grey", fg="white", borderwidth=0, command=lambda: show_calendar(cal_checkin))
    show_calendar_button_checkin.pack(side=tk.RIGHT)

    cal_checkin = Calendar(add_checkin_panel, selectmode="day", date_pattern="yyyy-mm-dd")
    cal_checkin.bind("<<CalendarSelected>>", lambda event: on_date_selected(cal_checkin, date_input_checkin))

    CO_Date = tk.Label(add_checkin_panel, text="Checkout Date:", font=("Arial", 10, "bold"), bg="cyan", fg="black")
    CO_Date.place(x=460, y=200)

    date_frame_checkout = tk.Frame(add_checkin_panel, bg="grey")
    date_frame_checkout.place(x=570, y=190)

    date_input_checkout = tk.Entry(date_frame_checkout, width=20, relief=tk.FLAT, borderwidth=10)
    date_input_checkout.pack(side=tk.LEFT)

    show_calendar_button_checkout = tk.Button(date_frame_checkout, text="📅", font=("Arial", 12), bg="grey", fg="white", borderwidth=0, command=lambda: show_calendar(cal_checkout))
    show_calendar_button_checkout.pack(side=tk.RIGHT)

    cal_checkout = Calendar(add_checkin_panel, selectmode="day", date_pattern="yyyy-mm-dd")
    cal_checkout.bind("<<CalendarSelected>>", lambda event: on_date_selected(cal_checkout, date_input_checkout))

    room_name_label = tk.Label(get_info_window, text="Room:", font=("Roboto", 12, "bold"), bg="cyan", fg="black")
    room_name_label.place(x=290, y=190)
    room_name_entry = tk.Entry(get_info_window, width=20, font=('Arial', 12,"bold"), bg='white', fg="Red")
    room_name_entry.place(x=350, y=190)
    room_name_entry.insert(0, selected_room)

    name_label = tk.Label(add_checkin_panel, text="Name (Optional):", font=("Roboto", 10, "bold"), bg="cyan", fg="black")
    name_label.place(x=80, y=162)
    name_entry = tk.Entry(add_checkin_panel, width=20, font=('Arial', 12), bg='white', fg='#000000')
    name_entry.place(x=200, y=162)

    contact_label = tk.Label(add_checkin_panel, text="Phone Number:", font=("Roboto", 10, "bold"), bg="cyan", fg="black")
    contact_label.place(x=90, y=200)
    phone_number_entry = tk.Entry(add_checkin_panel, width=20, font=('Arial', 12), bg='white', fg='#000000')
    phone_number_entry.place(x=200, y=200)

    guests_label = tk.Label(add_checkin_panel, text="# of Guests:", font=("Roboto", 10, "bold"), bg="cyan", fg="black")
    guests_label.place(x=117, y=240)
    
    guests_number_var = tk.StringVar()
    guests_number_entry = tk.Entry(add_checkin_panel, width=10, font=('Arial', 12), bg='white', fg='#000000', textvariable=guests_number_var)
    guests_number_entry.place(x=200, y=240)

    guests_number_var.trace_add("write", update_hidden_number_of_guests_entry)

    compute_days_label = tk.Label(add_checkin_panel, text="Number of Days:", font=("Roboto", 10, "bold"), bg="cyan", fg="black")
    compute_days_label.place(x=453, y=240)
    compute_days_entry = tk.Entry(add_checkin_panel, width=10, font=('Arial', 12), bg='white', fg='#000000')
    compute_days_entry.place(x=570, y=240)


    hidden_timein_entry = tk.Entry(add_checkin_panel, width=20, font=('Arial', 12), bg='white', fg='#000000')
    hidden_timein_entry.place(x=200, y=500)
    hidden_timein_entry.place_forget()

    create_time_selector(add_checkin_panel, 453, 280, "Timein (HH:MM):", hidden_timein_entry)


    hidden_timeout_entry = tk.Entry(add_checkin_panel, width=20, font=('Arial', 12), bg='white', fg='#000000')
    hidden_timeout_entry.place(x=200, y=540)
    hidden_timeout_entry.place_forget()

    create_time_selector(add_checkin_panel, 453, 320, "Timeout (HH:MM):", hidden_timeout_entry)


    services_label = tk.Label(add_checkin_panel, text="Services:", font=("Roboto", 10, "bold"), bg="cyan", fg="black")
    services_label.place(x=130, y=280)

    listbox = tk.Listbox(add_checkin_panel, selectmode=tk.MULTIPLE)
    listbox.place(x=200, y=280)

    services = ["Breakfast", "Lunch", "Dinner"]
    for service in services:
        listbox.insert(tk.END, service)

    hidden_listbox_entry = tk.Entry(add_checkin_panel, width=40, font=('Arial', 12), bg='white', fg='#000000')
    hidden_listbox_entry.place(x=200, y=560)
    hidden_listbox_entry.place_forget()

    selected_service_entry = tk.Entry(add_checkin_panel, width=40, font=('Arial', 12), bg='white', fg='#000000')
    selected_service_entry.place(x=200, y=400)
    selected_service_entry.place_forget()

    hidden_number_of_guests_entry = tk.Entry(add_checkin_panel, width=40, font=('Arial', 12), bg='white', fg='#000000')
    hidden_number_of_guests_entry.place(x=200, y=300)
    hidden_number_of_guests_entry.place_forget()

    listbox.bind('<<ListboxSelect>>', lambda event: update_hidden_listbox_entry())

    proceed_bill_button = tk.Button(add_checkin_panel, width="20", text="Next", font=("Botthanie", 12), bg="Blue", fg ="white", command=proceed_to_billing)
    proceed_bill_button.place(x=400, y=500)

    get_info_window.mainloop()

def open_see_list_window(parent, connection, refresh=False):

    if refresh and hasattr(open_see_list_window, 'see_list_window'):
        open_see_list_window.see_list_window.destroy()


    see_list_window = tk.Toplevel(parent)
    open_see_list_window.see_list_window = see_list_window  

    see_list_window.title("See List")
    see_list_window.overrideredirect(True)

    middle_width = parent.winfo_width()
    middle_height = parent.winfo_height()
    x = parent.winfo_rootx() + parent.winfo_width() // 2 - middle_width // 2
    y = parent.winfo_rooty() + parent.winfo_height() // 2 - middle_height // 2
    see_list_window.geometry(f"{middle_width}x{middle_height}+{x}+{y}")

    tree_frame = tk.Frame(see_list_window)
    tree_frame.pack(fill="both", expand=True, padx=30, pady=90)

    search_entry = tk.Entry(see_list_window, relief=tk.FLAT, borderwidth=10, highlightthickness=1, highlightbackground="black", width=50)
    search_entry.insert(0, "Search...") 
    search_entry.bind("<FocusIn>", lambda e: search_entry.delete(0, 'end') if search_entry.get() == "Search..." else None)
    search_entry.bind("<FocusOut>", lambda e: search_entry.insert(0, "Search..." if search_entry.get() == "" else search_entry.get()))
    search_entry.place(x=50, y=30)

    button_search = tk.Button(see_list_window, text="Search", font=("Roboto", 12), bg="blue", fg="white", width=10, command=lambda: search_data(search_entry.get()))
    button_search.place(x=390, y=33)

    style = ttk.Style()
    style.configure("Treeview.Heading", font=("Arial", 10, "bold"))

    tree = ttk.Treeview(tree_frame, columns=("Room_Name", "Check_in_Date", "Check_out_Date", "Bill", "Cash", "Change"))
    tree.heading("#0", text="Customer_ID")
    tree.heading("Room_Name", text="Room Name")
    tree.heading("Check_in_Date", text="Checkin Date")
    tree.heading("Check_out_Date", text="Checkout Date")
    tree.heading("Bill", text="Total Bill")
    tree.heading("Cash", text="Total Cash")
    tree.heading("Change", text="Total Change")

    tree.column("#0", width=0, stretch=tk.NO) 
    tree.column("Room_Name", width=150, anchor=tk.CENTER)
    tree.column("Check_in_Date", width=150, anchor=tk.CENTER)
    tree.column("Check_out_Date", width=150, anchor=tk.CENTER)
    tree.column("Bill", width=100, anchor=tk.CENTER)
    tree.column("Cash", width=100, anchor=tk.CENTER)
    tree.column("Change", width=100, anchor=tk.CENTER)

    button_dict = {}

    def fetch_data_from_database(show_popup=False):
        try:
            with connection.cursor() as cursor:
                sql = """
                SELECT ID, Room_Name, Check_in_Date, Check_out_Date, Bill, Cash, `Change`, 
                       Name, Services, Timein, Timeout, No_Guest, Number_Days
                FROM hotel_customer
                """
                cursor.execute(sql)
                rows = cursor.fetchall()
                tree.delete(*tree.get_children())
                for button in button_dict.values():
                    button.destroy()
                button_dict.clear()
                if not rows and show_popup:
                    messagebox.showinfo("No Data", "No data found.")
                else:
                    for row in rows:
                        item_id = tree.insert("", "end", text=row[0], values=row[1:])
                        
        except pymysql.Error as e:
            messagebox.showerror("Error", f"Error fetching data: {e}")

    def search_data(search_text):
        search_text = search_text.strip().lower()
        tree.delete(*tree.get_children())
        try:
            with connection.cursor() as cursor:
                sql = """
                SELECT ID, Room_Name, Check_in_Date, Check_out_Date, Bill, Cash, `Change`, 
                       Name, Services, Timein, Timeout, No_Guest, Number_Days
                FROM hotel_customer
                """
                cursor.execute(sql)
                rows = cursor.fetchall()
                if not rows:
                    messagebox.showinfo("No Data", "No data found.")
                for row in rows:
                    if search_text in str(row).lower():
                        item_id = tree.insert("", "end", text=row[0], values=row[1:])
        except pymysql.Error as e:
            messagebox.showerror("Error", f"Error fetching data: {e}")

    selected_row = None

    def on_tree_select(event):
        nonlocal selected_row
        selected_item = tree.focus()
        selected_row = tree.item(selected_item)['values']

    tree.bind("<<TreeviewSelect>>", on_tree_select)

    def fetch_refresh():
        fetch_data_from_database()
        see_list_window.after(10000, fetch_refresh)

    def checkout():
        if selected_row is None:
            messagebox.showwarning("Select a row", "Please select a row to checkout.")
            return

        selected_item = tree.selection()[0]
        customer_id = tree.item(selected_item)['text']
        room_name, check_in_date, check_out_date, bill, cash, change, name, services, time_in, time_out, no_guest, number_days = selected_row

        if cash == "":
     
            cash = simpledialog.askfloat("Cash Amount", "Enter cash amount:")
            if cash is None or cash == 0: 
                messagebox.showwarning("Invalid Cash Amount", "Invalid", parent=see_list_window)
                return
        else:
            try:
                cash = int(cash)  
            except ValueError:
                messagebox.showwarning("Invalid Cash Amount", "Invalid", parent=see_list_window)
                return

        if cash < bill:
            messagebox.showwarning("Insufficient Cash", "Cash amount must be equal to or greater than the bill amount.", parent=see_list_window)
            return

        try:
            with connection.cursor() as cursor:
       
                sql_insert_history = """
                    INSERT INTO checkout_table (id, room_number, Check_in_Date, Check_out_Date, Bill, Cash, `Change`)
                    VALUES (%s, %s, %s, %s, %s, %s, %s)
                """
                cursor.execute(sql_insert_history, (customer_id, room_name, check_in_date, check_out_date, bill, cash, change))
                
       
                sql_insert_available = "INSERT INTO available_rooms (room_number) VALUES (%s)"
                cursor.execute(sql_insert_available, (room_name,))
                
           
                sql_delete_customer = "DELETE FROM hotel_customer WHERE ID = %s"
                cursor.execute(sql_delete_customer, (customer_id,))
                
             
                connection.commit()

           
                tree.delete(selected_item)

                messagebox.showinfo("Success", f"Checked out customer {customer_id} from room {room_name}", parent=see_list_window)
                update_counts()
                fetch_data_from_database()
        except pymysql.Error as e:
            messagebox.showerror("Error", f"Error during checkout: {e}")
            
    def checkout13():
        try:
            with connection.cursor() as cursor:
                
         
                sql_insert_available = """
                    SELECT (id, room_number, Check_in_Date, Check_out_Date, Bill, Cash, `Change`)
                    VALUES (%s, %s, %s, %s, %s, %s, %s)
                """

                connection.commit()

                messagebox.showinfo(parent=see_list_window)
                update_counts()
                fetch_data_from_database()
        except pymysql.Error as e:
            messagebox.showerror("Error")

    def delete_customer():
        if selected_row is None:
            messagebox.showwarning("Select a row", "Please select a row to delete.")
            return

        selected_item = tree.selection()[0]
        customer_id = tree.item(selected_item)['text']
        room_name, check_in_date, check_out_date, bill, cash, change, name, services, time_in, time_out, no_guest, number_days = selected_row

        try:
            with connection.cursor() as cursor:
        
                sql_insert_history = """
                    INSERT INTO history_table (id, room_name, Check_in_Date, Check_out_Date, Bill, Cash, `Change`)
                    VALUES (%s, %s, %s, %s, %s, %s, %s)
                """
                cursor.execute(sql_insert_history, (customer_id, room_name, check_in_date, check_out_date, bill, cash, change))
                
 
                sql_insert_available = "INSERT INTO available_rooms (room_number) VALUES (%s)"
                cursor.execute(sql_insert_available, (room_name,))
                

                sql_delete_customer = "DELETE FROM hotel_customer WHERE ID = %s"
                cursor.execute(sql_delete_customer, (customer_id,))
                

                connection.commit()
             
                tree.delete(selected_item)

                messagebox.showinfo("Success", f"Done {customer_id}", parent=see_list_window)
                update_counts()
                fetch_data_from_database() 
        except pymysql.Error as e:
            messagebox.showerror("Error", f"Error during deletion: {e}")

    def view_customer():

        if selected_row is None:
            messagebox.showwarning("Select a row", "Please select a row to view.")
            return
        
        room_name, check_in_date, check_out_date, bill, cash, change, name, services, time_in, time_out, no_guest, number_days = selected_row

        customer_id = tree.item(tree.focus())['text']

        details = (
            f"Customer ID: {customer_id}\n"
            f"Name: {name}\n"
            f"Room Name: {room_name}\n"
            f"Services: {services}\n"
            f"Check-in Date: {check_in_date}\n"
            f"Check-out Date: {check_out_date}\n"
            f"Time in: {time_in}\n"
            f"Time out: {time_out}\n"
            f"Number of Guests: {no_guest}\n"
            f"Number of Days: {number_days}\n"
            f"Bill: {bill}\n"
            f"Cash: {cash}\n"
            f"Change: {change}"
        )

        display_details_message(details)

    def display_details_message(details):

        messagebox.showinfo("Customer Details", details, parent=see_list_window)

    def refresh_data():
        fetch_data_from_database()

    tree.pack(expand=True, fill="both")
    refresh_data()

    vsb = ttk.Scrollbar(tree_frame, orient="vertical", command=tree.yview)
    vsb.pack(side="right", fill="y")
    tree.configure(yscrollcommand=vsb.set)

    Checkout_btn = tk.Button(see_list_window, text="Checkout", font=("Roboto", 12), bg="Green", fg="white", width=10, command=checkout)
    Checkout_btn.place(x=300, y=650)

    Delete_btn = tk.Button(see_list_window, text="Delete", font=("Roboto", 12), bg="Red", fg="white", width=10, command=delete_customer)
    Delete_btn.place(x=480, y=650)

    view_btn = tk.Button(see_list_window, text="View", font=("Roboto", 12), bg="blue", fg="white", width=10, command=view_customer)
    view_btn.place(x=650, y=650)


    Refresh_btn = tk.Button(see_list_window, text="Refresh", font=("Roboto", 12), bg="Orange", fg="white", width=10, command=checkout13)
    Refresh_btn.place(x=840, y=650)

  
    fetch_data_from_database()


    fetch_refresh()


def fetch_data_from_database(show_popup=True):
        try:
            with connection.cursor() as cursor:
                sql = "SELECT Check_in_Date, Check_out_Date, Bill, Cash, `Change` FROM history_table"
                cursor.execute(sql)
                rows = cursor.fetchall()
        except pymysql.Error as e:
            messagebox.showerror("Error", f"Error fetching data: {e}")

def open_billing_window(parent, billing_data, refresh_function):
    def calculate_total_bill():
        room_prices = {
            "Room F03": 1000,
            "Room F06": 1000,
            "Room F09": 1000,
            "Room D02": 500,
            "Room D05": 500,
            "Room D08": 500,
            "Room S01": 250,
            "Room S04": 250,
            "Room S07": 250
        }

        service_prices = {
            "Breakfast": 100,
            "Lunch": 100,
            "Dinner": 100
        }

        rate_per_day = 350

        try:
            num_days = int(billing_data["num_days"])
            num_guests = int(billing_data["guests"])
        except ValueError:
            num_days = 0
            num_guests = 0

        room_name = billing_data["room_number"]
        services = billing_data["services"].split(', ')

        room_cost = room_prices.get(room_name, 0)
        service_cost = sum(service_prices.get(service, 0) for service in services) * num_guests
        daily_rate_cost = rate_per_day * num_days
        total_cost = room_cost + service_cost + daily_rate_cost

        total_bills_entry.delete(0, tk.END)
        total_bills_entry.insert(0, str(total_cost))

        try:
            cash_amount = float(total_cash_entry.get())
            change = cash_amount - total_cost
        except ValueError:
            change = 0

        total_change_entry.delete(0, tk.END)
        total_change_entry.insert(0, str(change))

        receipt_text.delete("1.0", tk.END)
        receipt_text.insert(tk.END, f"Receipt\n")
        receipt_text.insert(tk.END, f"----------------------------\n")
        receipt_text.insert(tk.END, f"Room: {room_name}\n")
        receipt_text.insert(tk.END, f"Room Cost: {room_cost}\n")
        receipt_text.insert(tk.END, f"Number of Guests: {num_guests}\n")
        receipt_text.insert(tk.END, f"Number of Days: {num_days}\n")
        receipt_text.insert(tk.END, f"Services: {', '.join(services)}\n")
        receipt_text.insert(tk.END, f"Service Cost: {service_cost}\n")
        receipt_text.insert(tk.END, f"Daily Rate Cost: {daily_rate_cost}\n")
        receipt_text.insert(tk.END, f"----------------------------\n")
        receipt_text.insert(tk.END, f"Total Cost: {total_cost}\n")

    def insert_into_database(total_bills_entry, total_cash_entry, total_change_entry, receipt_text):
        connection = pymysql.connect(
            host="localhost",
            user="root",
            password="",
            database="Hotel_Management_System"
        )

        try:
            with connection.cursor() as cursor:
                name = name_entry.get()
                room_name = room_name_entry.get()
                services = service_entry.get()
                checkin_date = checkin_date_entry.get()
                checkout_date = checkout_date_entry.get()
                timein = timeincheck_entry.get()
                timeout = timeoutcheck_entry.get()
                num_guests = number_guest_entry.get()
                num_days = number_days_entry.get()  
                total_bill = total_bills_entry.get()
                cash = total_cash_entry.get()
                change = total_change_entry.get()

                sql = "INSERT INTO hotel_customer (Name, Room_Name, Services, Check_in_Date, Check_out_Date, Timein, Timeout, No_Guest, Number_Days, Bill, Cash, `Change`) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"
                cursor.execute(sql, (name, room_name, services, checkin_date, checkout_date, timein, timeout, num_guests, num_days, total_bill, cash, change))
                connection.commit()

              
                cursor.execute("INSERT INTO occupied_room (room) SELECT room_number FROM available_rooms WHERE room_number = %s", (room_name,))
                connection.commit()

    
                cursor.execute("DELETE FROM available_rooms WHERE room_number = %s", (room_name,))
                connection.commit()
                
                messagebox.showinfo("Success", "Data inserted and room updated successfully!")
                
              
                refresh_function()

        finally:
            connection.close()

    def submit_bill():
        insert_into_database(total_bills_entry, total_cash_entry, total_change_entry, receipt_text)
        update_counts()

    def update_change(event):
        calculate_total_bill()

    billing_window = tk.Toplevel(parent)
    billing_window.title("Pricing")
    billing_window.overrideredirect(True)
    billing_window.configure(bg="white")

    middle_width = parent.winfo_width()
    middle_height = parent.winfo_height()
    parent.update_idletasks()
    x = parent.winfo_rootx() + parent.winfo_width() // 2 - middle_width // 2
    y = parent.winfo_rooty() + parent.winfo_height() // 2 - middle_height // 2
    billing_window.geometry(f"{middle_width}x{middle_height}+{x}+{y}")

    billing_panel = tk.Frame(billing_window, bg="cyan", width=900, height=550)
    billing_panel.pack_propagate(False)
    billing_panel.place(x=260, y=100)

    pay_bill_label = tk.Label(billing_window, text="Pay Bills", font=("Roboto", 24, "bold"), bg="cyan", fg="black")
    pay_bill_label.place(x=280, y=120)

    add_pay_bill_divider_panel = tk.Frame(billing_panel, bg="black", width=5000, height=2)
    add_pay_bill_divider_panel.pack_propagate(False)
    add_pay_bill_divider_panel.place(x=0, y=70)

    compute_days_label = tk.Label(billing_panel, text="Room:", font=("Roboto", 10, "bold"), bg="cyan", fg="black")
    compute_days_label.place(x=100, y=113)
    compute_days_label = tk.Label(billing_panel, text="Name:", font=("Roboto", 10, "bold"), bg="cyan", fg="black")
    compute_days_label.place(x=100, y=144)
    compute_days_label = tk.Label(billing_panel, text="# of Guest:", font=("Roboto", 10, "bold"), bg="cyan", fg="black")
    compute_days_label.place(x=73, y=173)
    compute_days_label = tk.Label(billing_panel, text="Services:", font=("Roboto", 10, "bold"), bg="cyan", fg="black")
    compute_days_label.place(x=82, y=204)

    compute_days_label = tk.Label(billing_panel, text="Checkin Date:", font=("Roboto", 10, "bold"), bg="cyan", fg="black")
    compute_days_label.place(x=497, y=113)
    compute_days_label = tk.Label(billing_panel, text="Checkout Date:", font=("Roboto", 10, "bold"), bg="cyan", fg="black")
    compute_days_label.place(x=490, y=144)
    compute_days_label = tk.Label(billing_panel, text="# of Days:", font=("Roboto", 10, "bold"), bg="cyan", fg="black")
    compute_days_label.place(x=523, y=173)
    compute_days_label = tk.Label(billing_panel, text="Timein:", font=("Roboto", 10, "bold"), bg="cyan", fg="black")
    compute_days_label.place(x=535, y=204)
    compute_days_label = tk.Label(billing_panel, text="Timeout:", font=("Roboto", 10, "bold"), bg="cyan", fg="black")
    compute_days_label.place(x=529, y=235)

    compute_days_label = tk.Label(billing_panel, text="Total Bill:", font=("Roboto", 10, "bold"), bg="cyan", fg="black")
    compute_days_label.place(x=300, y=353)
    compute_days_label = tk.Label(billing_panel, text="Total Cash:", font=("Roboto", 10, "bold"), bg="cyan", fg="black")
    compute_days_label.place(x=290, y=375)
    compute_days_label = tk.Label(billing_panel, text="Total Change:", font=("Roboto", 10, "bold"), bg="cyan", fg="black")
    compute_days_label.place(x=272, y=424)

    room_name_entry = tk.Entry(billing_panel, width=20, font=('Arial', 12), bg='white', fg='#000000')
    room_name_entry.place(x=150, y=110)
    room_name_entry.insert(0, billing_data["room_number"])

    name_entry = tk.Entry(billing_panel, width=20, font=('Arial', 12), bg='white', fg='#000000')
    name_entry.place(x=150, y=140)
    name_entry.insert(0, billing_data["name"])

    number_guest_entry = tk.Entry(billing_panel, width=20, font=('Arial', 12), bg='white', fg='#000000')
    number_guest_entry.place(x=150, y=170)
    number_guest_entry.insert(0, billing_data["guests"])

    service_entry = tk.Entry(billing_panel, width=20, font=('Arial', 12), bg='white', fg='#000000')
    service_entry.place(x=150, y=200)
    service_entry.insert(0, billing_data["services"])

    checkin_date_entry = tk.Entry(billing_panel, width=20, font=('Arial', 12), bg='white', fg='#000000')
    checkin_date_entry.place(x=600, y=110)
    checkin_date_entry.insert(0, billing_data["checkin_date"])

    checkout_date_entry = tk.Entry(billing_panel, width=20, font=('Arial', 12), bg='white', fg='#000000')
    checkout_date_entry.place(x=600, y=140)
    checkout_date_entry.insert(0, billing_data["checkout_date"])

    number_days_entry = tk.Entry(billing_panel, width=20, font=('Arial', 12), bg='white', fg='#000000')
    number_days_entry.place(x=600, y=170)
    number_days_entry.insert(0, billing_data["num_days"])

    timeincheck_entry = tk.Entry(billing_panel, width=20, font=('Arial', 12), bg='white', fg='#000000')
    timeincheck_entry.place(x=600, y=200)
    timeincheck_entry.insert(0, billing_data["timein"])

    timeoutcheck_entry = tk.Entry(billing_panel, width=20, font=('Arial', 12), bg='white', fg='#000000')
    timeoutcheck_entry.place(x=600, y=230)
    timeoutcheck_entry.insert(0, billing_data["timeout"])

    calculate_bill_button = tk.Button(billing_panel, width="15", text="Calculate Bills", font=("Botthanie", 12), bg="Green", fg ="white", command=calculate_total_bill)
    calculate_bill_button.place(x=400, y=280)

    total_bills_entry = tk.Entry(billing_panel, width=20, font=('Arial', 12), bg='white', fg='#000000')
    total_bills_entry.place(x=380, y=350)

    total_cash_entry = tk.Entry(billing_panel, width=20, font=('Arial', 12), bg='white', fg='#000000')
    total_cash_entry.place(x=380, y=370)

    total_change_entry = tk.Entry(billing_panel, width=20, font=('Arial', 12), bg='white', fg='#000000')
    total_change_entry.place(x=380, y=420)

    total_cash_entry.bind("<KeyRelease>", update_change)

    submit_bill_button = tk.Button(billing_panel, width="15", text="Submit", font=("Botthanie", 12), bg="Blue", fg ="white", command=submit_bill)
    submit_bill_button.place(x=400, y=470)

    receipt_text = tk.Text(billing_panel, width=25, height=15, font=("Arial", 10), bg="white", fg="black")
    receipt_text.place(x=5, y=300)

    fetch_occupied_room_count
    fetch_occupied_rooms_data
    update_counts
    fetch_refresh_table


def open_history_window(parent):

    def fetch_data_from_database():
        try:
            with connection.cursor() as cursor:
                sql = "SELECT Check_in_Date, Check_out_Date, Bill, Cash, `Change` FROM history_table"
                cursor.execute(sql)
                rows = cursor.fetchall()
                for row in rows:
                    tree.insert("", "end", values=row)
        except pymysql.Error as e:
            messagebox.showerror("Error", f"Error fetching data: {e}")


    def search_data():
        search_text = search_entry.get().strip().lower()
        tree.delete(*tree.get_children()) 
        try:
            with connection.cursor() as cursor:
                sql = "SELECT Check_in_Date, Check_out_Date, Bill, Cash, `Change` FROM history_table"
                cursor.execute(sql)
                rows = cursor.fetchall()
                for row in rows:
                    if any(search_text in str(cell).lower() for cell in row):
                        tree.insert("", "end", values=row)
        except pymysql.Error as e:
            messagebox.showerror("Error", f"Error fetching data: {e}")


    history_window = tk.Toplevel(parent)
    history_window.title("History")
    history_window.overrideredirect(True)  


    middle_width = parent.winfo_width()
    middle_height = parent.winfo_height()
    x = parent.winfo_rootx() + parent.winfo_width() // 2 - middle_width // 2
    y = parent.winfo_rooty() + parent.winfo_height() // 2 - middle_height // 2
    history_window.geometry(f"{middle_width}x{middle_height}+{x}+{y}")


    tree_frame = tk.Frame(history_window)
    tree_frame.pack(fill="both", expand=True, pady=100)


    search_entry = tk.Entry(history_window, relief=tk.FLAT, borderwidth=10, highlightthickness=1, highlightbackground="black", width=50)
    search_entry.insert(0, "Search...") 
    search_entry.bind("<FocusIn>", lambda e: search_entry.delete(0, 'end') if search_entry.get() == "Search..." else None)
    search_entry.bind("<FocusOut>", lambda e: search_entry.insert(0, "Search...") if search_entry.get() == "" else None)
    search_entry.place(x=50, y=30)


    button_search = tk.Button(history_window, text="Search", font=("Roboto", 12, ""), bg="blue", fg="White", width=10, command=search_data)
    button_search.place(x=390, y=33)


    tree = ttk.Treeview(tree_frame, columns=("Check_in_Date", "Check_out_Date", "Bill", "Cash", "Change"))
    tree.heading("#0", text="")
    tree.heading("Check_in_Date", text="Checkin Date")
    tree.heading("Check_out_Date", text="Checkout Date")
    tree.heading("Bill", text="Total Bill")
    tree.heading("Cash", text="Total Cash")
    tree.heading("Change", text="Total Change")

    tree.column("#0", width=0, stretch=tk.NO)  
    tree.column("Check_in_Date", width=150, anchor=tk.CENTER)
    tree.column("Check_out_Date", width=150, anchor=tk.CENTER)
    tree.column("Bill", width=100, anchor=tk.CENTER)
    tree.column("Cash", width=100, anchor=tk.CENTER)
    tree.column("Change", width=100, anchor=tk.CENTER)


    fetch_data_from_database()

    tree.pack(expand=True, fill="both")


    vsb = ttk.Scrollbar(tree_frame, orient="vertical", command=tree.yview)
    vsb.pack(side="right", fill="y")
    tree.configure(yscrollcommand=vsb.set)


    hsb = ttk.Scrollbar(tree_frame, orient="horizontal", command=tree.xview)
    hsb.pack(side="bottom", fill="x")
    tree.configure(xscrollcommand=hsb.set)

def open_check_out_window(parent):
 
    def fetch_data_from_database():
        try:
            with connection.cursor() as cursor:
               
                sql = "SELECT `Check_in_Date`, `Check_out_Date`, `Bill`, `Cash`, `Change` FROM checkout_table"
                cursor.execute(sql)
                rows = cursor.fetchall()
              
                tree.delete(*tree.get_children())
             
                for row in rows:
                    tree.insert("", "end", values=row)
        except pymysql.Error as e:
            messagebox.showerror("Error", f"Error fetching data: {e}")

 
    def search_data():
        search_text = search_entry.get().strip().lower()
        tree.delete(*tree.get_children())
        try:
            with connection.cursor() as cursor:
                sql = "SELECT `Check_in_Date`, `Check_out_Date`, `Bill`, `Cash`, `Change` FROM checkout_table"
                cursor.execute(sql)
                rows = cursor.fetchall()
                for row in rows:
                    if search_text in str(row).lower():
                        tree.insert("", "end", values=row)
        except pymysql.Error as e:
            messagebox.showerror("Error", f"Error fetching data: {e}")


    def refresh_data():
        fetch_data_from_database()
     
        check_out_window.after(10000, refresh_data)

  
    check_out_window = tk.Toplevel(parent)
    check_out_window.title("Check Out")
    check_out_window.overrideredirect(True)

 
    middle_width = parent.winfo_width()
    middle_height = parent.winfo_height()
    parent.update_idletasks()
    x = parent.winfo_rootx() + parent.winfo_width() // 2 - middle_width // 2
    y = parent.winfo_rooty() + parent.winfo_height() // 2 - middle_height // 2
    check_out_window.geometry(f"{middle_width}x{middle_height}+{x}+{y}")


    tree_frame = tk.Frame(check_out_window)
    tree_frame.pack(fill="both", expand=True, pady=100)

  
    search_entry = tk.Entry(check_out_window, relief=tk.FLAT, borderwidth=10, highlightthickness=1, highlightbackground="black", width=50)
    search_entry.insert(0, "Search...") 
    search_entry.bind("<FocusIn>", lambda e: search_entry.delete(0, 'end') if search_entry.get() == "Search..." else None)
    search_entry.bind("<FocusOut>", lambda e: search_entry.insert(0, "Search...") if search_entry.get() == "" else None)
    search_entry.place(x=50, y=30)


    button_search = tk.Button(check_out_window, text="Search", font=("Roboto", 12), bg="blue", fg="white", width=10, command=search_data)
    button_search.place(x=390, y=33)


    tree = ttk.Treeview(tree_frame, columns=("Check_in_Date", "Check_out_Date", "Bill", "Cash", "Change"))
    tree.heading("#0", text="") 
    tree.heading("Check_in_Date", text="Checkin Date")
    tree.heading("Check_out_Date", text="Checkout Date")
    tree.heading("Bill", text="Total Bill")
    tree.heading("Cash", text="Total Cash")
    tree.heading("Change", text="Total Change")


    tree.column("#0", width=0, stretch=tk.NO) 
    tree.column("Check_in_Date", anchor=tk.CENTER, width=150)
    tree.column("Check_out_Date", anchor=tk.CENTER, width=150)
    tree.column("Bill", anchor=tk.CENTER, width=100)
    tree.column("Cash", anchor=tk.CENTER, width=100)
    tree.column("Change", anchor=tk.CENTER, width=100)


    fetch_data_from_database()


    tree.pack(expand=True, fill="both")


    vsb = ttk.Scrollbar(tree_frame, orient="vertical", command=tree.yview)
    vsb.pack(side="right", fill="y")
    tree.configure(yscrollcommand=vsb.set)


    hsb = ttk.Scrollbar(tree_frame, orient="horizontal", command=tree.xview)
    hsb.pack(side="bottom", fill="x")
    tree.configure(xscrollcommand=hsb.set)


    refresh_data()

    check_out_window.mainloop()
    
def open_pricing_window(parent):

    pricing_window = tk.Toplevel(parent)
    pricing_window.title("Princing")
    pricing_window.overrideredirect(True)
    pricing_window.configure(bg="white") 

 
    middle_width = parent.winfo_width()
    middle_height = parent.winfo_height()
    parent.update_idletasks()
    x = parent.winfo_rootx() + parent.winfo_width() // 2 - middle_width // 2
    y = parent.winfo_rooty() + parent.winfo_height() // 2 - middle_height // 2
    pricing_window.geometry(f"{middle_width}x{middle_height}+{x}+{y}")
    
    room_prices1_panel = tk.Frame(pricing_window, bg="cyan", width=400, height=200)
    room_prices1_panel.pack_propagate(False)
    room_prices1_panel.place(x=50, y=65)

    room_prices2_panel = tk.Frame(pricing_window, bg="cyan", width=400, height=200)
    room_prices2_panel.pack_propagate(False)
    room_prices2_panel.place(x=50, y=300)

    room_prices3_panel = tk.Frame(pricing_window, bg="cyan", width=400, height=200)
    room_prices3_panel.pack_propagate(False)
    room_prices3_panel.place(x=50, y=530)

    service_panel = tk.Frame(pricing_window, bg="cyan", width=400, height=405)
    service_panel.pack_propagate(False)
    service_panel.place(x=510, y=67)

    rate_panel = tk.Frame(pricing_window, bg="cyan", width=400, height=205)
    rate_panel.pack_propagate(False)
    rate_panel.place(x=960, y=67)

    Price_label = tk.Label(pricing_window, text="Prices:", font=("Verdana", 24, "bold"), bg="White", fg="black")
    Price_label.place(x=15, y=10)

    Price_label = tk.Label(room_prices1_panel, text="Room S01", font=("Verdana", 15, "bold"), bg="cyan", fg="black")
    Price_label.place(x=15, y=40)
    Price_label = tk.Label(room_prices1_panel, text="Room S04", font=("Verdana", 15, "bold"), bg="cyan", fg="black")
    Price_label.place(x=15, y=80)
    Price_label = tk.Label(room_prices1_panel, text="Room S07", font=("Verdana", 15, "bold"), bg="cyan", fg="black")
    Price_label.place(x=15, y=120)
    Price_label = tk.Label(room_prices1_panel, text="=", font=("Verdana", 20, "bold"), bg="cyan", fg="black")
    Price_label.place(x=180, y=75)
    Price_label = tk.Label(room_prices1_panel, text="250", font=("Verdana", 30, "bold"), bg="cyan", fg="Red")
    Price_label.place(x=250, y=67)


    Price_label = tk.Label(room_prices2_panel, text="Room D02", font=("Verdana", 15, "bold"), bg="cyan", fg="black")
    Price_label.place(x=15, y=40)
    Price_label = tk.Label(room_prices2_panel, text="Room D05", font=("Verdana", 15, "bold"), bg="cyan", fg="black")
    Price_label.place(x=15, y=80)
    Price_label = tk.Label(room_prices2_panel, text="Room D08", font=("Verdana", 15, "bold"), bg="cyan", fg="black")
    Price_label.place(x=15, y=120)
    Price_label = tk.Label(room_prices2_panel, text="=", font=("Verdana", 20, "bold"), bg="cyan", fg="black")
    Price_label.place(x=180, y=75)
    Price_label = tk.Label(room_prices2_panel, text="500", font=("Verdana", 30, "bold"), bg="cyan", fg="Red")
    Price_label.place(x=250, y=67)


    Price_label = tk.Label(room_prices3_panel, text="Room F03", font=("Verdana", 15, "bold"), bg="cyan", fg="black")
    Price_label.place(x=15, y=40)
    Price_label = tk.Label(room_prices3_panel, text="Room F06", font=("Verdana", 15, "bold"), bg="cyan", fg="black")
    Price_label.place(x=15, y=80)
    Price_label = tk.Label(room_prices3_panel, text="Room F09", font=("Verdana", 15, "bold"), bg="cyan", fg="black")
    Price_label.place(x=15, y=120)
    Price_label = tk.Label(room_prices3_panel, text="=", font=("Verdana", 20, "bold"), bg="cyan", fg="black")
    Price_label.place(x=180, y=75)
    Price_label = tk.Label(room_prices3_panel, text="1000", font=("Verdana", 30, "bold"), bg="cyan", fg="Red")
    Price_label.place(x=230, y=67)

    Price_label = tk.Label(service_panel, text="Breakfast", font=("Verdana", 15, "bold"), bg="cyan", fg="black")
    Price_label.place(x=30, y=130)
    Price_label = tk.Label(service_panel, text="Lunch", font=("Verdana", 15, "bold"), bg="cyan", fg="black")
    Price_label.place(x=30, y=170)
    Price_label = tk.Label(service_panel, text="Dinner", font=("Verdana", 15, "bold"), bg="cyan", fg="black")
    Price_label.place(x=30, y=210)
    Price_label = tk.Label(service_panel, text="=", font=("Verdana", 20, "bold"), bg="cyan", fg="black")
    Price_label.place(x=180, y=165)
    Price_label = tk.Label(service_panel, text="100", font=("Verdana", 30, "bold"), bg="cyan", fg="Red")
    Price_label.place(x=250, y=158) 

    Price_label = tk.Label(rate_panel, text="Rate per Day", font=("Verdana", 15, "bold"), bg="cyan", fg="black")
    Price_label.place(x=30, y=82)
    Price_label = tk.Label(rate_panel, text="=", font=("Verdana", 20, "bold"), bg="cyan", fg="black")
    Price_label.place(x=200, y=75)
    Price_label = tk.Label(rate_panel, text="350", font=("Verdana", 30, "bold"), bg="cyan", fg="Red")
    Price_label.place(x=250, y=68) 

def open_rooms_window(parent):

    rooms_window = tk.Toplevel(parent)
    rooms_window.title("Princing")
    rooms_window.overrideredirect(True) 
    rooms_window.configure(bg="white")


    middle_width = parent.winfo_width()
    middle_height = parent.winfo_height()
    parent.update_idletasks()
    x = parent.winfo_rootx() + parent.winfo_width() // 2 - middle_width // 2
    y = parent.winfo_rooty() + parent.winfo_height() // 2 - middle_height // 2
    rooms_window.geometry(f"{middle_width}x{middle_height}+{x}+{y}")

    room_prices1_panel = tk.Frame(rooms_window, bg="cyan", width=1300, height=600)
    room_prices1_panel.pack_propagate(False)
    room_prices1_panel.place(x=50, y=63)

    Single_Bed_Room_label = tk.Label(rooms_window, text="Standard Single Room", font=("Roboto", 12, 'bold'), bg="cyan", fg="red")
    Single_Bed_Room_label.place(x=210, y=150)
    Double_Bed_Room_label = tk.Label(rooms_window, text="Deluxe Double Room", font=("Roboto", 12, 'bold'), bg="cyan", fg="red")
    Double_Bed_Room_label.place(x=630, y=150)
    Family_Suite_Room_label = tk.Label(rooms_window, text="Family Suite", font=("Roboto", 12,'bold'), bg="cyan", fg="red")
    Family_Suite_Room_label.place(x=1070, y=150)

    button_positions = [
        (205, 250),   # Position for Room 01 s
        (620, 250),  # Position for Room 02 d
        (1030, 250),  # Position for Room 03  f
        (205, 350),  # Position for Room 04 s
        (620, 350), # Position for Room 05 d
        (1030, 350), # Position for Room 06 f
        (205, 450),  # Position for Room 07 s
        (620, 450), # Position for Room 08 d
        (1030, 450), # Position for Room 09 f
    ]

    button_texts = ["Room S01", "Room D02", "Room F03", "Room S04", "Room D05", "Room F06", "Room S07", "Room D08", "Room F09"]
    for i, (text, pos) in enumerate(zip(button_texts, button_positions)):
        button = tk.Button(rooms_window, text=text, font=("Roboto", 20), bg="blue", fg="yellow", width=10, state="normal")
        button.place(x=pos[0], y=pos[1])

    Description = tk.Button(rooms_window, text="Description", font=("Verdana", 10, ""), bg="Green", fg="White", border=1,command= lambda:open_description_window(parent))
    Description.place(x=260, y=180)
    Description = tk.Button(rooms_window, text="Description", font=("Verdana", 10, ""), bg="Green", fg="White", border=1,command= lambda:open_description2_window(parent))
    Description.place(x=670, y=180)
    Description = tk.Button(rooms_window, text="Description", font=("Verdana", 10, ""), bg="Green", fg="White", border=1,command= lambda:open_description3_window(parent))
    Description.place(x=1075, y=180) 


button_check_out = tk.Button(left_panel, text="Dashboard", font=("Botthanie", 12, "bold"), bg="#00ADB5", border=5, command=lambda: open_dashboard(root))
button_check_out.grid(row=4, column=0, sticky="ew")
button_checkin = tk.Button(left_panel, text="Check In", font=("Botthanie", 12, "bold"), bg="#00ADB5", border=5, command=lambda: open_choose_rooms_window(middle_panel))
button_checkin.grid(row=5, column=0, sticky="ew")
button_history = tk.Button(left_panel, text="Checked out", font=("Botthanie", 12, "bold"), bg="#00ADB5", border=5, command=lambda: open_check_out_window(middle_panel))
button_history.grid(row=7, column=0, sticky="ew")
button_see_list = tk.Button(left_panel, text="Record", font=("Botthanie", 12, "bold"), bg="#00ADB5", border=5,  command=lambda: open_see_list_window(middle_panel, connection, refresh=True))
button_see_list.grid(row=6, column=0, sticky="ew")
button_check_out = tk.Button(left_panel, text="History", font=("Botthanie", 12, "bold"), bg="#00ADB5", border=5, command=lambda: open_history_window(middle_panel))
button_check_out.grid(row=8, column=0, sticky="ew")
button_check_out = tk.Button(left_panel, text="Pricing", font=("Botthanie", 12, "bold"), bg="#00ADB5", border=5,command=lambda: open_pricing_window(middle_panel))
button_check_out.grid(row=9, column=0, sticky="ew")
button_check_out = tk.Button(left_panel, text="Rooms", font=("Botthanie", 12, "bold"), bg="#00ADB5", border=5,command=lambda: open_rooms_window(middle_panel))
button_check_out.grid(row=10, column=0, sticky="ew")
 

root.mainloop()